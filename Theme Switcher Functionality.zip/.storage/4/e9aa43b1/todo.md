# Code Rewrite Project - Clean React Components

## Components to Create:
1. **ThemeProvider** - Theme management with light/dark/midnight modes
2. **MaintenanceWrapper** - Maintenance mode component with glitch effect
3. **ParticleBackground** - Interactive particle effect component
4. **Toaster** - Toast notification component
5. **App.tsx** - Updated main app component
6. **Index.tsx** - Demo page showcasing all components

## Implementation Plan:
- Use TypeScript for type safety
- Implement modern React hooks (useState, useEffect, useContext)
- Use Tailwind CSS for styling
- Create reusable, maintainable components
- Add proper error handling and accessibility

## File Structure:
- src/components/theme-provider.tsx
- src/components/maintenance-wrapper.tsx
- src/components/particle-background.tsx
- src/components/ui/toaster.tsx (update existing)
- src/App.tsx (update)
- src/pages/Index.tsx (update)
- src/hooks/use-mouse-position.tsx
- src/types/index.ts