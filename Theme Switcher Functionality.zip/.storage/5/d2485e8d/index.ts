export interface MousePosition {
  x: number;
  y: number;
}

export interface Particle {
  x: number;
  y: number;
  translateX: number;
  translateY: number;
  size: number;
  alpha: number;
  targetAlpha: number;
  dx: number;
  dy: number;
  magnetism: number;
}

export interface ParticleBackgroundProps {
  className?: string;
  quantity?: number;
  staticity?: number;
  ease?: number;
  size?: number;
  refresh?: boolean;
  color?: string;
  vx?: number;
  vy?: number;
}

export interface ThemeProviderProps {
  children: React.ReactNode;
  themes?: string[];
  attribute?: string;
  defaultTheme?: string;
  enableSystem?: boolean;
  storageKey?: string;
}

export interface MaintenanceWrapperProps {
  children: React.ReactNode;
  maintenance?: boolean;
}