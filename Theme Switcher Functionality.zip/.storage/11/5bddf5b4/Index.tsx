import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { ParticleBackground } from '@/components/particle-background';
import { useTheme } from '@/components/theme-provider';
import { toast } from 'sonner';

export default function Index() {
  const { theme, setTheme } = useTheme();
  const [showParticles, setShowParticles] = useState(true);
  const [maintenance, setMaintenance] = useState(false);

  const handleThemeChange = (newTheme: 'light' | 'dark' | 'midnight') => {
    setTheme(newTheme);
    toast.success(`Theme changed to ${newTheme}`);
  };

  const handleMaintenanceToggle = () => {
    setMaintenance(!maintenance);
    toast.info(`Maintenance mode ${!maintenance ? 'enabled' : 'disabled'}`);
  };

  if (maintenance) {
    return (
      <div className="flex w-screen h-screen text-center justify-center items-center bg-black">
        <div className="relative">
          <p className="text-2xl sm:text-3xl lg:text-5xl text-yellow-500 uppercase relative overflow-hidden">
            <span className="relative block animate-pulse">
              Website Under Maintenance
            </span>
          </p>
          <Button 
            onClick={() => setMaintenance(false)}
            className="mt-8 bg-yellow-500 text-black hover:bg-yellow-400"
          >
            Exit Maintenance Mode
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Particle Background */}
      {showParticles && (
        <ParticleBackground
          className="absolute inset-0 -z-10"
          quantity={80}
          staticity={30}
          ease={40}
          size={0.6}
        />
      )}

      {/* Main Content */}
      <div className="relative z-10 container mx-auto px-6 py-12">
        <div className="max-w-4xl mx-auto space-y-12">
          
          {/* Header */}
          <div className="text-center space-y-4">
            <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              Modern React Components
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Clean, reusable components built with TypeScript, React hooks, and Tailwind CSS
            </p>
            <div className="flex items-center justify-center gap-2">
              <Badge variant="secondary">TypeScript</Badge>
              <Badge variant="secondary">React 18</Badge>
              <Badge variant="secondary">Tailwind CSS</Badge>
              <Badge variant="secondary">Shadcn/ui</Badge>
            </div>
          </div>

          {/* Theme Controls */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                🎨 Theme Provider
                <Badge>Current: {theme}</Badge>
              </CardTitle>
              <CardDescription>
                Switch between light, dark, and midnight themes with persistent storage
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-3">
                <Button 
                  variant={theme === 'light' ? 'default' : 'outline'}
                  onClick={() => handleThemeChange('light')}
                  className="flex-1"
                >
                  ☀️ Light
                </Button>
                <Button 
                  variant={theme === 'dark' ? 'default' : 'outline'}
                  onClick={() => handleThemeChange('dark')}
                  className="flex-1"
                >
                  🌙 Dark
                </Button>
                <Button 
                  variant={theme === 'midnight' ? 'default' : 'outline'}
                  onClick={() => handleThemeChange('midnight')}
                  className="flex-1"
                >
                  🌌 Midnight
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Particle Controls */}
          <Card>
            <CardHeader>
              <CardTitle>✨ Interactive Particles</CardTitle>
              <CardDescription>
                Mouse-reactive particle system with theme-based colors
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Show Particles</span>
                <Switch 
                  checked={showParticles}
                  onCheckedChange={setShowParticles}
                />
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Move your mouse around to see the magnetic effect!
              </p>
            </CardContent>
          </Card>

          {/* Maintenance Mode */}
          <Card>
            <CardHeader>
              <CardTitle>🚧 Maintenance Mode</CardTitle>
              <CardDescription>
                Toggle maintenance mode with animated glitch effects
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Maintenance Mode</span>
                <Switch 
                  checked={maintenance}
                  onCheckedChange={handleMaintenanceToggle}
                />
              </div>
            </CardContent>
          </Card>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>🎯 Key Features</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-sm">TypeScript for type safety</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-sm">Modern React hooks</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-sm">Responsive design</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-sm">Accessible components</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>🚀 Performance</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span className="text-sm">Optimized animations</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span className="text-sm">Canvas-based particles</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span className="text-sm">Efficient re-renders</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span className="text-sm">Memory management</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Demo Actions */}
          <Card>
            <CardHeader>
              <CardTitle>🎮 Interactive Demo</CardTitle>
              <CardDescription>
                Try out the toast notifications and other interactive features
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <Button onClick={() => toast.success('Success!')}>
                  Success Toast
                </Button>
                <Button onClick={() => toast.error('Error occurred!')}>
                  Error Toast
                </Button>
                <Button onClick={() => toast.info('Information')}>
                  Info Toast
                </Button>
                <Button onClick={() => toast.warning('Warning!')}>
                  Warning Toast
                </Button>
              </div>
            </CardContent>
          </Card>

        </div>
      </div>
    </div>
  );
}