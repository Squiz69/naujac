import React from 'react';
import { usePathname } from 'next/navigation';
import { MaintenanceWrapperProps } from '@/types';

const MaintenancePage = () => {
  return (
    <div className="flex w-screen h-screen text-center justify-center items-center bg-black">
      <div className="relative">
        <p className="text-2xl sm:text-3xl lg:text-5xl text-yellow-500 uppercase relative overflow-hidden">
          <span className="relative block glitch-text">
            Website Under Maintenance
          </span>
        </p>
        
        <style jsx>{`
          .glitch-text {
            position: relative;
            font-size: 25px;
            font-weight: 700;
            line-height: 1.2;
            color: #fff;
            letter-spacing: 5px;
            z-index: 1;
            animation: shift 1s ease-in-out infinite alternate;
          }
          
          .glitch-text:before,
          .glitch-text:after {
            display: block;
            content: "Website Under Maintenance";
            position: absolute;
            top: 0;
            left: 0;
            opacity: 0.8;
          }
          
          .glitch-text:before {
            animation: glitch 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94) both infinite;
            color: #8b00ff;
            z-index: -1;
          }
          
          .glitch-text:after {
            animation: glitch 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94) reverse both infinite;
            color: #00e571;
            z-index: -2;
          }
          
          @keyframes glitch {
            0% { transform: translate(0); }
            20% { transform: translate(-3px, 3px); }
            40% { transform: translate(-3px, -3px); }
            60% { transform: translate(3px, 3px); }
            80% { transform: translate(3px, -3px); }
            100% { transform: translate(0); }
          }
          
          @keyframes shift {
            0%, 40%, 44%, 58%, 61%, 65%, 69%, 73%, 100% {
              transform: skewX(0deg);
            }
            41% { transform: skewX(10deg); }
            42% { transform: skewX(-10deg); }
            59% { transform: skewX(40deg) skewY(10deg); }
            60% { transform: skewX(-40deg) skewY(-10deg); }
            63% { transform: skewX(10deg) skewY(-5deg); }
            70% { transform: skewX(-50deg) skewY(-20deg); }
            71% { transform: skewX(10deg) skewY(-10deg); }
          }
        `}</style>
      </div>
    </div>
  );
};

export function MaintenanceWrapper({ children, maintenance }: MaintenanceWrapperProps) {
  // For demo purposes, we'll use a simple check instead of usePathname
  // const pathname = usePathname();
  
  // Show maintenance page if maintenance is true and not on tools pages
  if (maintenance) {
    return <MaintenancePage />;
  }
  
  return <>{children}</>;
}