import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bot, Zap, Users, Shield, Code, Rocket } from "lucide-react";

const features = [
  {
    icon: Bot,
    title: "AI-Powered Agents",
    description: "Intelligent agents that understand your requirements and collaborate to build applications automatically.",
    badge: "Core Feature",
    gradient: "from-blue-500 to-cyan-500"
  },
  {
    icon: Users,
    title: "Team Collaboration",
    description: "Multiple AI agents work together seamlessly, each specialized in different aspects of development.",
    badge: "Collaboration",
    gradient: "from-purple-500 to-pink-500"
  },
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Deploy applications in minutes, not hours. Our optimized workflow accelerates your development cycle.",
    badge: "Performance",
    gradient: "from-yellow-500 to-orange-500"
  },
  {
    icon: Code,
    title: "Clean Code Generation",
    description: "Generate production-ready, maintainable code that follows best practices and industry standards.",
    badge: "Quality",
    gradient: "from-green-500 to-emerald-500"
  },
  {
    icon: Shield,
    title: "Enterprise Security",
    description: "Built with security-first principles, ensuring your applications and data remain protected.",
    badge: "Security",
    gradient: "from-red-500 to-rose-500"
  },
  {
    icon: Rocket,
    title: "One-Click Deploy",
    description: "Deploy to any platform with a single click. Support for major cloud providers and edge networks.",
    badge: "Deployment",
    gradient: "from-indigo-500 to-purple-500"
  }
];

export default function Features() {
  return (
    <section className="py-24 bg-white dark:bg-slate-900">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="text-center mb-20">
          <Badge variant="outline" className="mb-4 px-4 py-2 text-sm font-medium">
            Platform Features
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-slate-300 bg-clip-text text-transparent">
            Everything you need to build amazing apps
          </h2>
          <p className="text-xl text-slate-600 dark:text-slate-400 max-w-3xl mx-auto">
            MGX provides a comprehensive platform with intelligent AI agents, seamless collaboration, and powerful deployment tools.
          </p>
        </div>

        {/* Features grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <Card 
                key={index} 
                className="group relative overflow-hidden border-0 bg-gradient-to-br from-white to-slate-50 dark:from-slate-800 dark:to-slate-900 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2"
              >
                {/* Gradient overlay */}
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-500`}></div>
                
                <CardHeader className="relative z-10">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-r ${feature.gradient} shadow-lg`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {feature.badge}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl font-bold text-slate-900 dark:text-white group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:bg-clip-text group-hover:from-slate-900 group-hover:to-slate-700 dark:group-hover:from-white dark:group-hover:to-slate-300 transition-all duration-300">
                    {feature.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="relative z-10">
                  <CardDescription className="text-slate-600 dark:text-slate-400 leading-relaxed">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-20">
          <div className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-full font-semibold hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 transform hover:scale-105 cursor-pointer shadow-xl">
            <Zap className="w-5 h-5" />
            Explore All Features
          </div>
        </div>
      </div>
    </section>
  );
}