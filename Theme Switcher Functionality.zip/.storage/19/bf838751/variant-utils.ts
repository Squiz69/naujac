import { type ClassValue, clsx } from 'clsx';

type ConfigSchema = Record<string, Record<string, ClassValue>>;

type ConfigVariants<T extends ConfigSchema> = {
  [Variant in keyof T]?: keyof T[Variant] | null | undefined;
};

type ConfigVariantsWithClassProp<T extends ConfigSchema> = ConfigVariants<T> & {
  class?: ClassValue;
  className?: ClassValue;
};

type Config<T> = T extends ConfigSchema
  ? {
      variants?: T;
      defaultVariants?: ConfigVariants<T>;
      compoundVariants?: Array<
        ConfigVariants<T> & {
          class?: ClassValue;
          className?: ClassValue;
        }
      >;
    }
  : never;

type VariantProps<Component extends (...args: any) => any> = Omit<
  Parameters<Component>[0],
  'class' | 'className'
>;

const falsyToString = (value: unknown): string => (typeof value === 'boolean' ? `${value}` : value === 0 ? '0' : value || '');

export const cva = <T extends ConfigSchema>(
  base?: ClassValue,
  config?: Config<T>
): ((props?: ConfigVariantsWithClassProp<T>) => string) => {
  return (props) => {
    if (config?.variants == null) {
      return clsx(base, props?.class, props?.className);
    }

    const { variants, defaultVariants } = config;

    const getVariantClassNames = Object.keys(variants).map((variant: keyof T) => {
      const variantProp = props?.[variant as keyof typeof props];
      const defaultVariantProp = defaultVariants?.[variant];

      if (variantProp === null) return null;

      const variantKey = (falsyToString(variantProp) || falsyToString(defaultVariantProp)) as keyof T[typeof variant];

      return variants[variant][variantKey];
    });

    const propsWithoutUndefined = props && Object.entries(props).reduce<Record<string, unknown>>((acc, [key, value]) => {
      if (value === undefined) {
        return acc;
      }

      acc[key] = value;
      return acc;
    }, {});

    const getCompoundVariantClassNames = config?.compoundVariants?.reduce(
      (acc, compoundVariant) => {
        const { class: cvClass, className: cvClassName, ...compoundVariantOptions } = compoundVariant;

        return Object.entries(compoundVariantOptions).every(([key, value]) => {
          const propValue = { ...defaultVariants, ...propsWithoutUndefined }[key];

          return Array.isArray(value) ? value.includes(propValue) : propValue === value;
        })
          ? [...acc, cvClass, cvClassName]
          : acc;
      },
      [] as ClassValue[]
    );

    return clsx(
      base,
      getVariantClassNames,
      getCompoundVariantClassNames,
      props?.class,
      props?.className
    );
  };
};

export type { VariantProps, ConfigSchema, ConfigVariants };