import { config } from '@/lib/config';

export interface ApiRequestOptions {
  path: string;
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  body?: any;
  headers?: Record<string, string>;
  session?: {
    id?: string;
    token?: string;
    Auth?: {
      Id: string;
      Token: string;
    };
  };
  query?: Record<string, string | number>;
  endpoint?: string;
  contentType?: boolean;
}

export async function apiRequest(options: ApiRequestOptions): Promise<Response> {
  const {
    path,
    method,
    body,
    headers,
    session,
    query,
    endpoint,
    contentType = true,
  } = options;

  // Extract session info
  const sessionData = session && typeof session === 'object' && session !== null ? {
    Id: 'Auth' in session ? session.Auth!.Id : session.id || 'NULL',
    Token: 'Auth' in session ? session.Auth!.Token : session.token || 'NULL',
  } : null;

  const url = buildUrl({ query, path, endpoint });

  const requestHeaders: Record<string, string> = {
    ...headers,
    ...(contentType ? { 'content-type': 'application/json; charset=utf-8' } : {}),
    ...(sessionData ? {
      'x-id': String(sessionData.Id),
      'x-token': sessionData.Token,
    } : {}),
  };

  const requestBody = typeof body === 'string' ? body : JSON.stringify(body);
  const requestMethod = body && !method ? 'POST' : method || 'GET';

  return await fetch(url, {
    headers: requestHeaders,
    body: requestBody,
    method: requestMethod,
    credentials: 'include',
    mode: 'cors',
  });
}

export function buildUrl(options: {
  path: string;
  query?: Record<string, string | number>;
  endpoint?: string;
}): string {
  const { path, query, endpoint } = options;
  const baseUrl = endpoint || config.getApiUrl();
  const fullPath = path.startsWith('/') ? path : `/${path}`;
  const queryString = query ? `?${buildQueryString(query)}` : '';
  
  return baseUrl + fullPath + queryString;
}

export function buildQueryString(
  params: Record<string, string | number>,
  encode = true
): string {
  const pairs: string[] = [];
  
  for (const key in params) {
    const value = String(params[key]);
    const encodedValue = encode ? encodeURIComponent(value) : value;
    pairs.push(`${key}=${encodedValue}`);
  }
  
  return pairs.join('&');
}

export interface RandomStringOptions {
  customChars?: string;
  prefix?: string;
  suffix?: string;
  randomPrefixChars?: string;
}

export function generateRandomString(
  pattern: string,
  length: number,
  options?: RandomStringOptions
): string {
  const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  
  let chars = '';
  if (pattern.includes('a')) chars += uppercase.toLowerCase();
  if (pattern.includes('A')) chars += uppercase;
  if (pattern.includes('#')) chars += '0123456789';
  if (pattern.includes('!')) chars += '!@#$%^&*()_-+=[{]};:>|./?';
  if (options?.customChars) chars += options.customChars;

  let result = options?.prefix || '';
  
  if (options?.randomPrefixChars) {
    const randomChar = options.randomPrefixChars[
      Math.round(Math.random() * (options.randomPrefixChars.length - 1))
    ];
    result += randomChar;
    length--;
  }

  for (let i = length; i > 0; i--) {
    result += chars[Math.round(Math.random() * (chars.length - 1))];
  }

  return result + (options?.suffix || '');
}