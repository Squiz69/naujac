export interface AppConfig {
  hosts: {
    app: {
      root: string;
      prod: string;
      dev: string;
    };
    api: {
      root: string;
      dev: string;
      prod: string;
    };
    partial: {
      root: string;
      prod: string;
      dev: string;
    };
    gateway: {
      root: string;
      prod: string;
      dev: string;
    };
  };
  discord: {
    oauth_id: string;
    invite: string | null;
  };
}

const appConfig: AppConfig = {
  hosts: {
    app: {
      root: 'example.com',
      prod: 'app.example.com',
      dev: 'dev.example.com',
    },
    api: {
      root: 'example.com',
      dev: 'api-dev.example.com',
      prod: 'api.example.com',
    },
    partial: {
      root: 'example.com',
      prod: 'www.example.com',
      dev: 'www-dev.example.com',
    },
    gateway: {
      root: 'example.com',
      prod: 'gateway.example.com',
      dev: 'gateway-dev.example.com',
    },
  },
  discord: {
    oauth_id: '1347890020807082065',
    invite: null,
  },
};

export function getHostUrl(
  hostType: keyof AppConfig['hosts'],
  includeProtocol: boolean | string = true
): string {
  let protocol = '';
  
  if (includeProtocol === true) {
    protocol = typeof window !== 'undefined' ? window.location.protocol + '//' : 'https://';
  } else if (typeof includeProtocol === 'string') {
    protocol = includeProtocol.replace(/[:\/]+$/, '') + '://';
  }
  
  const host = appConfig.hosts[hostType];
  const environment = process.env.NODE_ENV === 'production' ? 'prod' : 'dev';
  
  return protocol + host[environment];
}

export const config = {
  ...appConfig,
  getApiUrl: (includeProtocol?: boolean | string) => getHostUrl('api', includeProtocol),
  getAppUrl: (includeProtocol?: boolean | string) => getHostUrl('app', includeProtocol),
  getGatewayUrl: (includeProtocol?: boolean | string) => getHostUrl('gateway', includeProtocol),
};