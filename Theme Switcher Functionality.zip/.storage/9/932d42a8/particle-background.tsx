import React, { useRef, useEffect, useState } from 'react';
import { useMousePosition } from '@/hooks/use-mouse-position';
import { useTheme } from '@/components/theme-provider';
import { Particle, ParticleBackgroundProps } from '@/types';

export function ParticleBackground({
  className = '',
  quantity = 100,
  staticity = 50,
  ease = 50,
  size = 0.4,
  refresh = false,
  color,
  vx = 0,
  vy = 0,
}: ParticleBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const contextRef = useRef<CanvasRenderingContext2D | null>(null);
  const particles = useRef<Particle[]>([]);
  const mousePosition = useMousePosition();
  const mouseRef = useRef({ x: 0, y: 0 });
  const canvasSize = useRef({ w: 0, h: 0 });
  const { theme } = useTheme();
  
  // Get theme-based color if not provided
  const particleColor = color || 
    (theme === 'dark' ? '#ef4444' : 
     theme === 'midnight' ? '#93c5fd' : '#000000');

  const dpr = typeof window !== 'undefined' ? window.devicePixelRatio : 1;

  useEffect(() => {
    if (canvasRef.current) {
      contextRef.current = canvasRef.current.getContext('2d');
    }
    
    initCanvas();
    animate();
    
    const handleResize = () => initCanvas();
    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [particleColor]);

  useEffect(() => {
    updateMousePosition();
  }, [mousePosition.x, mousePosition.y]);

  useEffect(() => {
    initCanvas();
  }, [refresh]);

  const initCanvas = () => {
    resizeCanvas();
    drawParticles();
  };

  const updateMousePosition = () => {
    if (canvasRef.current) {
      const rect = canvasRef.current.getBoundingClientRect();
      const { w, h } = canvasSize.current;
      const x = mousePosition.x - rect.left - w / 2;
      const y = mousePosition.y - rect.top - h / 2;
      
      const inside = x < w / 2 && x > -w / 2 && y < h / 2 && y > -h / 2;
      
      if (inside) {
        mouseRef.current.x = x;
        mouseRef.current.y = y;
      }
    }
  };

  const resizeCanvas = () => {
    if (containerRef.current && canvasRef.current && contextRef.current) {
      particles.current = [];
      
      canvasSize.current.w = containerRef.current.offsetWidth;
      canvasSize.current.h = containerRef.current.offsetHeight;
      
      canvasRef.current.width = canvasSize.current.w * dpr;
      canvasRef.current.height = canvasSize.current.h * dpr;
      canvasRef.current.style.width = `${canvasSize.current.w}px`;
      canvasRef.current.style.height = `${canvasSize.current.h}px`;
      
      contextRef.current.scale(dpr, dpr);
    }
  };

  const createParticle = (): Particle => {
    const x = Math.floor(Math.random() * canvasSize.current.w);
    const y = Math.floor(Math.random() * canvasSize.current.h);
    const particleSize = Math.floor(Math.random() * 2) + size;
    
    return {
      x,
      y,
      translateX: 0,
      translateY: 0,
      size: particleSize,
      alpha: 0,
      targetAlpha: parseFloat((Math.random() * 0.6 + 0.1).toFixed(1)),
      dx: (Math.random() - 0.5) * 0.1,
      dy: (Math.random() - 0.5) * 0.1,
      magnetism: 0.1 + Math.random() * 4,
    };
  };

  const hexToRgb = (hex: string): [number, number, number] => {
    hex = hex.replace('#', '');
    if (hex.length === 3) {
      hex = hex.split('').map(char => char + char).join('');
    }
    const bigint = parseInt(hex, 16);
    return [(bigint >> 16) & 255, (bigint >> 8) & 255, bigint & 255];
  };

  const drawParticle = (particle: Particle, update = false) => {
    if (contextRef.current) {
      const { x, y, translateX, translateY, size, alpha } = particle;
      
      contextRef.current.translate(translateX, translateY);
      contextRef.current.beginPath();
      contextRef.current.arc(x, y, size, 0, Math.PI * 2);
      
      const rgb = hexToRgb(particleColor);
      contextRef.current.fillStyle = `rgba(${rgb.join(', ')}, ${alpha})`;
      contextRef.current.fill();
      contextRef.current.setTransform(dpr, 0, 0, dpr, 0, 0);
      
      if (!update) {
        particles.current.push(particle);
      }
    }
  };

  const clearCanvas = () => {
    if (contextRef.current) {
      contextRef.current.clearRect(0, 0, canvasSize.current.w, canvasSize.current.h);
    }
  };

  const drawParticles = () => {
    clearCanvas();
    
    for (let i = 0; i < quantity; i++) {
      drawParticle(createParticle());
    }
  };

  const remapValue = (
    value: number,
    start1: number,
    end1: number,
    start2: number,
    end2: number
  ): number => {
    const remapped = ((value - start1) * (end2 - start2)) / (end1 - start1) + start2;
    return remapped > 0 ? remapped : 0;
  };

  const animate = () => {
    clearCanvas();
    
    particles.current.forEach((particle, index) => {
      const edge = [
        particle.x + particle.translateX - particle.size,
        canvasSize.current.w - particle.x - particle.translateX - particle.size,
        particle.y + particle.translateY - particle.size,
        canvasSize.current.h - particle.y - particle.translateY - particle.size,
      ].reduce((a, b) => Math.min(a, b));
      
      const closeness = remapValue(edge, 0, 20, 0, 1);
      
      if (closeness > 1) {
        particle.alpha += 0.02;
        if (particle.alpha > particle.targetAlpha) {
          particle.alpha = particle.targetAlpha;
        }
      } else {
        particle.alpha = particle.targetAlpha * closeness;
      }
      
      particle.x += particle.dx + vx;
      particle.y += particle.dy + vy;
      particle.translateX += 
        (mouseRef.current.x / (staticity / particle.magnetism) - particle.translateX) / ease;
      particle.translateY += 
        (mouseRef.current.y / (staticity / particle.magnetism) - particle.translateY) / ease;
      
      drawParticle(particle, true);
      
      if (
        particle.x < -particle.size ||
        particle.x > canvasSize.current.w + particle.size ||
        particle.y < -particle.size ||
        particle.y > canvasSize.current.h + particle.size
      ) {
        particles.current.splice(index, 1);
        drawParticle(createParticle());
      }
    });
    
    window.requestAnimationFrame(animate);
  };

  return (
    <div className={className} ref={containerRef} aria-hidden="true">
      <canvas ref={canvasRef} className="size-full" />
    </div>
  );
}